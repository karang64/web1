﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMS
{
    public partial class TMSRegister : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;

        static SqlConnection getConnection()
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
                return new SqlConnection(conStr);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtUserName.Focus();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Text;
            con = getConnection();
            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();
            com = new SqlCommand("procTMSAddUser1092305", con);
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.Add(new SqlParameter("@username", userName));
            com.Parameters.Add(new SqlParameter("@password", password));
            int i = com.ExecuteNonQuery();
            if(i>0)
            {
                Response.Write("<script type='text/javascript'>alert('User Added Successfully!');</script>");
                FormsAuthentication.SignOut();
                Response.Redirect("TMSLogin.aspx");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('There is a problem in adding user!');</script>");
            }
            con.Close();
        }
    }
}