﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMS
{
    public partial class TMSMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.User.Identity.Name == null || HttpContext.Current.User.Identity.Name == "")
            {
//                Response.Write(HttpContext.Current.User.Identity.Name);
                btnLogin.Enabled = true;
                btnSignOut.Visible = false;
                btnRegister.Enabled = true;
            }
            else
            {
  //              Response.Write(HttpContext.Current.User.Identity.Name);
                btnLogin.Enabled = false;
                btnSignOut.Visible = true;
                btnRegister.Enabled = false;
            }
        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("TMSHome.aspx");
        }

        protected void btnBook_Click(object sender, EventArgs e)
        {
            Response.Redirect("TMSBook.aspx");
        }

        protected void btnView_Click(object sender, EventArgs e)
        {
            Response.Redirect("TMSView.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("TMSLogin.aspx");
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            FormsAuthentication.RedirectFromLoginPage("Guest", false);
            Response.Redirect("TMSRegister.aspx");
        }

        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            FormsAuthentication.RedirectToLoginPage();
        }
    }
}