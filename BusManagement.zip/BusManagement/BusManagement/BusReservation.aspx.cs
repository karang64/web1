﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BusManagement
{
    public partial class BusReservation : System.Web.UI.Page
    {
        string start, destination, seatType;
        static int amount=0,nop=0,tamt=0;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txt_amount0_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btn_amt_Click(object sender, EventArgs e)
        {
            start = dd_from.SelectedItem.Text;
            destination = dd_to.SelectedItem.Text;
            seatType = dd_stype.SelectedItem.Text;
   
            if(seatType.Equals("Sleeper A/C"))
            {
                if(start.Equals("Chennai"))
                {
                    if(destination.Equals("Madurai"))
                        amount=3000;
                    else
                        amount=3500;
                }
                if(start.Equals("Trichy"))
                {
                    if(destination.Equals("Madurai"))
                        amount=2500;
                    else
                        amount=3000;
                }

            }
            else if(seatType.Equals("Sleeper Non A/C"))
            {
                if(start.Equals("Chennai"))
                {
                    if(destination.Equals("Madurai"))
                        amount=2000;
                    else
                        amount=2500;
                }
                if(start.Equals("Trichy"))
                {
                    if(destination.Equals("Madurai"))
                        amount=1500;
                    else
                        amount=2000;
                }
            }
            txt_amount.Text = amount.ToString();
        }

        protected void btn_camt_Click(object sender, EventArgs e)
        {
            string temp = txt_nop.Text;
            nop=Convert.ToInt32(temp);
            tamt = nop * amount;
            txt_tamt.Text = tamt.ToString();
        }
    }
}