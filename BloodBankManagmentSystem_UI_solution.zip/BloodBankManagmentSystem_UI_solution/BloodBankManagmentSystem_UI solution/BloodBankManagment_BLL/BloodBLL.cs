﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BloodBankManagment_Types;
using BloodBankManagment_BO;
using BloodBankManagment_DAL;

namespace BloodBankManagment_BLL
{
    public class BloodBLL : IBloodBLL
    {
        public void AddDonor(IBloodBO objbo)
        {
            IBloodDAL dalobj = new BloodDAL();
            dalobj.AddDonor(objbo);
        }
        public DataSet ViewDonor(IBloodBO obj)
        {
            IBloodDAL dalobj = new BloodDAL();
           return dalobj.ViewDonor(obj);
        }
        public void UpdateDonor(IBloodBO objbo)
        {
            IBloodDAL dalobj = new BloodDAL();
            dalobj.UpdateDonor(objbo);
        }
    }
}
