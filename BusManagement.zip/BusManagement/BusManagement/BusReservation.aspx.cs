﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BusManagement
{
    public partial class BusReservation : System.Web.UI.Page
    {
        static SqlConnection con;
        static SqlCommand cmd;
        
        string start, destination, seatType;
        static int amount=0,nop=0,tamt=0;
        

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txt_amount0_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btn_amt_Click(object sender, EventArgs e)
        {
            
            
        }

        protected void btn_camt_Click(object sender, EventArgs e)
        {
           
        }

        static SqlConnection GetConnection()
        {
            string conStr="Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
  
        }
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            con = GetConnection();
            start = dd_from.SelectedItem.Text;
            destination = dd_to.SelectedItem.Text;
            string x = txt_nop.Text;
            int nop = Convert.ToInt16(x);
            string x1 = txt_tamt.Text;
            int tamt = Convert.ToInt16(x1);

            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("res_passenger", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@Start", start));
            cmd.Parameters.Add(new SqlParameter("@Destination", destination));
            cmd.Parameters.Add(new SqlParameter("@NoofPassengers", nop));
            cmd.Parameters.Add(new SqlParameter("@TotalAmount", tamt));

            SqlParameter ridParam = cmd.Parameters.Add("@Rid", SqlDbType.Int);
            ridParam.Direction = ParameterDirection.Output;

            int res = cmd.ExecuteNonQuery();
            if (res > 0)
                Response.Write("Reservation ID : " + (int)ridParam.Value);
               // return (int)ridParam.Value;

            //return res;
            //con.Close();

        }

        //public int AddReservation()
        //{
            
        //}
    }
}