﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BloodMgmt_Types
{
  public  interface IDonor
    {

        int Donorid  { get; set; }
        string Donorname { get; set; }
        int Bloodgroupid { get; set; }
        string Donoraddress { get; set; }
        string Contactno { get; set; }
        string Registrationdate { get; set; }



    }
}
