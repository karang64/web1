﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user"] == null)
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                from_DropDownList.Items.Insert(0, new ListItem("From", "From"));
                from_DropDownList.Items.Insert(1, new ListItem("Chennai", "1"));
                from_DropDownList.Items.Insert(2, new ListItem("Trichy", "2"));

                to_DropDownList.Items.Insert(0, new ListItem("To", "To"));
                to_DropDownList.Items.Insert(1, new ListItem("Madurai", "1"));
                to_DropDownList.Items.Insert(2, new ListItem("Coimbatore", "2"));

                seatType_DropDownList.Items.Insert(0, new ListItem("Seat Type", "Seat Type"));
                seatType_DropDownList.Items.Insert(1, new ListItem("Sleeper AC", "1"));
                seatType_DropDownList.Items.Insert(2, new ListItem("Sleeper Non AC", "2"));
            }

        }

        protected void submit_Button_Click(object sender, EventArgs e)
        {

            String from, to;
            int nop, totAmt, i ;
            i = 0;
            from = from_DropDownList.SelectedItem.ToString();
            to = to_DropDownList.SelectedItem.ToString();
            nop = int.Parse(nop_TextBox.Text);
            totAmt=int.Parse(totalAmt_TextBox.Text);

            SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("usp_addBooking1213929", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("from", from));
            cmd.Parameters.Add(new SqlParameter("to", to));
            cmd.Parameters.Add(new SqlParameter("nop", nop));
            cmd.Parameters.Add(new SqlParameter("totAmt", totAmt));
            i=cmd.ExecuteNonQuery();
                        
            con.Close();
            if (i == 1)
            {
                alertUser("Booking added successfully.");
            }
            else
                alertUser("Please try again.");
        }

        void alertUser(String message)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alerts", "javascript:alert('"+message+"')", true);
        }

        protected void from_DropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}