﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BloodBankManagment_Types;
using BloodBankManagment_BO;
using BloodBankManagment_BLL;

namespace BloodBankManagmentSystem_UI
{
    public partial class AddDonor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LabelID.Text = Session["BloodGroupName"].ToString(); 
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            IBloodBO objbo = new BloodBO();
            objbo.DonorName = TextDonorName.Text;
            objbo.DonorAddress = TextAddress.Text;
            objbo.BloodGroupID =Convert.ToInt16(Session["BloodGroupID"]);
            objbo.RegistrationDate = Convert.ToDateTime(TextRDate.Text);
            objbo.BloodGroupName = LabelID.Text;
            objbo.Contact = Convert.ToInt32(TextContact.Text);
            IBloodBLL bllobj = new BloodBLL();
            bllobj.AddDonor(objbo);
            Response.Write("added successful");
        }
       
    }
}