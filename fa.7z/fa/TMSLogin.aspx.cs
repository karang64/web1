﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMS
{
    public partial class TMSLogin : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;

        static SqlConnection getConnection()
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
                return new SqlConnection(conStr);
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                FormsAuthentication.SignOut();
                txtUserName.Focus();
            }
            catch(Exception ex)
            {

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Text;
            con = getConnection();
            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();
            com = new SqlCommand("procTMSValidate1092305", con);
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.Add(new SqlParameter("@username", userName));
            SqlDataReader stdReader = com.ExecuteReader();
            while(stdReader.Read())
            {
                if(stdReader[0].ToString()==userName || stdReader[1].ToString() == password)
                {
                    FormsAuthentication.RedirectFromLoginPage(userName, false);
                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('Invalid Username or Password!');</script>");
                    txtUserName.Focus();
                }
            }
            con.Close();
        }
    }
}