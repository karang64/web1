﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBankManagment_Types;

namespace BloodBankManagment_BO
{
    public class BloodBO : IBloodBO
    {
        int donorID;
        string donorName;
        int bloodGroupID;
        string bloodGroupName;
        string donorAddress;
        DateTime registrationDate;
        int contact;

        public BloodBO(int donorID, string donorname, int bloodGroupID,string bloodGroupName, string donorAddress, DateTime registrationDate, int contact)
        {
            DonorID = donorID;
            DonorName = donorname;
            BloodGroupID = bloodGroupID;
            BloodGroupName = bloodGroupName;
            DonorAddress = donorAddress;
            RegistrationDate = registrationDate;
            Contact = contact;
        }
        public BloodBO()
        {

        }

        public int DonorID
        {
            get
            {
                return donorID;
            }

            set
            {
                donorID = value;
            }
        }

        public string DonorName
        {
            get
            {
                return donorName;
            }

            set
            {
                donorName = value;
            }
        }

        public int BloodGroupID
        {
            get
            {
                return bloodGroupID;
            }

            set
            {
                bloodGroupID = value;
            }
        }

        public string DonorAddress
        {
            get
            {
                return donorAddress;
            }

            set
            {
                donorAddress = value;
            }
        }

        public DateTime RegistrationDate
        {
            get
            {
                return registrationDate;
            }

            set
            {
                registrationDate = value;
            }
        }

        public int Contact
        {
            get
            {
                return contact;
            }

            set
            {
                contact = value;
            }
        }

        public string BloodGroupName
        {
            get
            {
                return bloodGroupName;
            }

            set
            {
                bloodGroupName = value;
            }
        }
    }
}
