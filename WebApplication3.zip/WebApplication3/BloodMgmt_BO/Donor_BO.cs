﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BloodMgmt_Types;

namespace BloodMgmt_BO
{
   public class Donor_BO:IDonor
    {
        int donorid;
        string donorname;
        int bloodgroupid;
        string donoraddress;
        string contactno;
        string registrationdate;

        public int Donorid
        {
            get
            {
                return donorid;
            }

            set
            {
                donorid = value;
            }
        }

        public string Donorname
        {
            get
            {
                return donorname;
            }

            set
            {
                donorname = value;
            }
        }

        public int Bloodgroupid
        {
            get
            {
                return bloodgroupid;
            }

            set
            {
                bloodgroupid = value;
            }
        }

        public string Donoraddress
        {
            get
            {
                return donoraddress;
            }

            set
            {
                donoraddress = value;
            }
        }

        public string Contactno
        {
            get
            {
                return contactno;
            }

            set
            {
                contactno = value;
            }
        }

        public string Registrationdate
        {
            get
            {
                return registrationdate;
            }

            set
            {
                registrationdate = value;
            }
        }

      
    }
}
