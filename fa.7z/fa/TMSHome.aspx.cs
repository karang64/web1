﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMS
{
    public partial class TMSHome : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        string userName = "Guest";

        static SqlConnection getConnection()
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
                return new SqlConnection(conStr);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.User.Identity.Name == "Guest")
                Response.Redirect("TMSRegister.aspx");
                if (HttpContext.Current.User.Identity.Name == null)
                userName = "Guest";
            else
                userName = HttpContext.Current.User.Identity.Name;
            lblUser.Text = "Welcome, " + userName;
            con = getConnection();
            con.Open();
            com = new SqlCommand("select count(username) as Total from tblTMSBooking1092305 where username="+userName, con);
            com.CommandType = System.Data.CommandType.Text;
            DataSet ds = new DataSet();
            string sql = "select username from tblTMSBooking1092305 where username = '"+userName+"'";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, con);
                da.Fill(ds);
                lblNOB.Text = "No. of Bookings you have made is "+ds.Tables[0].Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                lblNOB.Text = "No. of Bookings you have made is NA";
            }
        }
    }
}