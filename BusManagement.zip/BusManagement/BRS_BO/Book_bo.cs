﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BRS_BO
{
    public class Book_BO
    {
        public int ReservationID
        {
            get;
            set;
        }
        public string Start
        {
            get;
            set;
        }
        public string Destination
        {
            get;
            set;
        }
        public int NoofPassengers
        {
            get;
            set;
        }
        public int TotalAmount
        {
            get;
            set;
        }
    }
}
