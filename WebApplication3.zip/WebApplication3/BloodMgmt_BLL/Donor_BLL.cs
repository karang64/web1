﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BloodMgmt_Types;
using BloodMgmt_DAL;
using System.Data;

namespace BloodMgmt_BLL
{
    public class Donor_BLL:IDonorBLL
    {

        public int Add_Donor(IDonor objDonor)
        {
            IDonorDAL objDal = new Donor_DAL();
            int i = objDal.AddDonor(objDonor);
            return i;

        }


        public DataSet View_Donor(int bloodgrpid)
        {
            IDonorDAL objDal = new Donor_DAL();
            DataSet ds = new DataSet();
            ds = objDal.ViewDonor(bloodgrpid);
            return ds;
        }

        public int Update_Donor(IDonor objDonor)
        {
            IDonorDAL objDal = new Donor_DAL();
            int i = objDal.UpdateDoner(objDonor);
            return i;

        }

        public int View_DonorCount(int bloodgrpid)
        {
            IDonorDAL objDal = new Donor_DAL();
           
           int i = objDal.ViewDonorCount(bloodgrpid);
            return i;
        }

        int IDonorBLL.View_DonorCount(int bloodgrpid)
        {
            throw new NotImplementedException();
        }
    }
}
