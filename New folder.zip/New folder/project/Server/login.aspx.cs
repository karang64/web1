﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace travel
{
    public partial class login : System.Web.UI.Page
    {
        static SqlConnection con;
        static SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        static SqlConnection GetConnection()
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }

        }
        protected void submit_Click(object sender, EventArgs e)
        {
            try {
                con = GetConnection();
                string uid = userid.Text;
                string pas = pass.Text;


                if (con.State == ConnectionState.Closed)
                    con.Open();

                cmd = new SqlCommand("clogin", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@uid", uid));
                cmd.Parameters.Add(new SqlParameter("@pass", pas));

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Response.Redirect("Home1.aspx");
                 }
                con.Close();
            }

            catch
            {
                con.Close();

            }
  
        }
    }
}