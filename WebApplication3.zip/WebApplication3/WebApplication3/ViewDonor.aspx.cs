﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BloodMgmt_Types;
using BloodMgmt_BLL;
using BloodMgmt_BO;
using System.Data;
namespace WebApplication3
{
    public partial class ViewDonor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            grvBind();
        }


        public void grvBind()
        {
            int bloodgrpid = ddlBloodGroup.SelectedIndex;
            // Session["BloodGroupName"] = ddlBloodGroup.Text;
            IDonorBLL objBLL = new Donor_BLL();
            DataSet ds = objBLL.View_Donor(bloodgrpid);
            GridDonor.DataSource = ds;
            GridDonor.DataBind();

            lbl_DonorCount.Text =(objBLL.View_DonorCount(bloodgrpid)).ToString();

        }

        protected void ddlBloodGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridDonor_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

            GridDonor.EditIndex = -1;
            grvBind();
        }

        protected void GridDonor_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            IDonorBLL objBLL = new Donor_BLL();
            GridViewRow gvr = GridDonor.Rows[e.RowIndex];
            IDonor objDonor = new Donor_BO();

            int bloodgrpid = ddlBloodGroup.SelectedIndex;

            objDonor.Donorid = bloodgrpid;
            objDonor.Donorname = (gvr.FindControl("txtDonorname") as TextBox).Text;
            objDonor.Donoraddress = (gvr.FindControl("txtDaddress") as TextBox).Text;
            objDonor.Contactno= (gvr.FindControl("txt_contact") as TextBox).Text;

            int i = objBLL.Update_Donor(objDonor);

            GridDonor.EditIndex = -1;
            grvBind();
        }

        protected void GridDonor_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridDonor.EditIndex = e.NewEditIndex;
            grvBind();
        }
    }
}