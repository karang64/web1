﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BloodBankManagment_BO;
using BloodBankManagment_Types;
using System.Configuration;

namespace BloodBankManagment_DAL
{
    public class BloodDAL : IBloodDAL
    {
        public int AddDonor(IBloodBO objbo)
        {
            int result;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            SqlCommand cmd = new SqlCommand("proc_AddDonor1185427", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@DonorName",objbo.DonorName);
            cmd.Parameters.AddWithValue("@BloodGroupID",objbo.BloodGroupID);
            cmd.Parameters.AddWithValue("@DonorAddress",objbo.DonorAddress);
            cmd.Parameters.AddWithValue("@RegistrationDate",objbo.RegistrationDate);
            cmd.Parameters.AddWithValue("@contact", objbo.Contact);
            SqlParameter param = new SqlParameter();
            param.Direction = ParameterDirection.Output;
            param.ParameterName = "@DonorID";
            param.SqlDbType = SqlDbType.Int;
            cmd.Parameters.Add(param);
            con.Open();
            result = cmd.ExecuteNonQuery();
            objbo.DonorID = (int)param.Value;
            con.Close();
            if(result>0)
                {
                Console.WriteLine("added succesfully");
            }
            return result;
        }
        public DataSet ViewDonor(IBloodBO obj)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("proc_ViewDonor1185427", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BloodGroupID",obj.BloodGroupID);
        
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public int UpdateDonor(IBloodBO objbo)
        {
            int result;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            SqlCommand cmd = new SqlCommand("proc_up", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@did", objbo.DonorID);
            cmd.Parameters.AddWithValue("@dname", objbo.DonorName);
            cmd.Parameters.AddWithValue("@dadd", objbo.DonorAddress);
            cmd.Parameters.AddWithValue("@contact", objbo.Contact);
            con.Open();
            result = cmd.ExecuteNonQuery();
            con.Close();
            return result;
        }
    }
}
