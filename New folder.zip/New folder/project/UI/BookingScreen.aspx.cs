﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TBookingSystem
{
    public partial class BookingScreen : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           //string x = boofrom.SelectedItem.Text;
           // if (x.Equals("Chennai"))
           // {
           //     booto.Items.Insert(0, new ListItem("Bangalore", "1"));
           //     booto.Items.Insert(1, new ListItem("Kanyakumari", "2"));
           //     booto.Items.Insert(2, new ListItem("Hyderabad", "3"));
           //     booto.Items.Insert(3, new ListItem("Madurai", "4"));


           // }
           // if (x.Equals("Bangalore"))
           // {
           //     booto.Items.Insert(0, new ListItem("Chennai", "1"));
           //     booto.Items.Insert(1, new ListItem("Kanyakumari", "2"));
           //     booto.Items.Insert(2, new ListItem("Hyderabad", "3"));
           //     booto.Items.Insert(3, new ListItem("Madurai", "4"));

           // }
           // if (x.Equals("Kanyakumari"))
           // {
           //     booto.Items.Insert(0, new ListItem("Chennai", "1"));
           //     booto.Items.Insert(1, new ListItem("Bangalore", "2"));
           //     booto.Items.Insert(2, new ListItem("Hyderabad", "3"));
           //     booto.Items.Insert(3, new ListItem("Madurai", "4"));
           // }
           // if (x.Equals("Hyderabad"))
           // {
           //     booto.Items.Insert(0, new ListItem("Chennai", "1"));
           //     booto.Items.Insert(1, new ListItem("Kanyakumari", "3"));
           //     booto.Items.Insert(2, new ListItem("Bangalore", "2"));
           //     booto.Items.Insert(3, new ListItem("Madurai", "4"));
           // }
           // if (x.Equals("Madurai"))
           // {
           //     booto.Items.Insert(0, new ListItem("Chennai", "1"));
           //     booto.Items.Insert(3, new ListItem("Bangalore", "2"));
           //     booto.Items.Insert(1, new ListItem("Kanyakumari", "3"));
           //     booto.Items.Insert(2, new ListItem("Hyderabad", "4"));
                

           // }

        }

        protected void boodate_SelectionChanged(object sender, EventArgs e)
        {
            string day = boodate.SelectedDate.Day.ToString();
            string month = boodate.SelectedDate.Month.ToString();
            string year = boodate.SelectedDate.Year.ToString();
            string final = day +"/"+ month +"/"+ year;

            boodate2.Text = final;
        }

        protected void boofrom_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}