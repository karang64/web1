﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace BloodBankManagmentSystem_UI
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FormsAuthentication.Authenticate(TextUser.Text, TextPass.Text))
            {
                Session["UserName"] = TextUser.Text;
                FormsAuthentication.RedirectFromLoginPage(TextUser.Text, false);
            }
            else
            {
                Response.Write("invalid credentials");
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}