﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BusManagement
{
    public partial class BusReservation : System.Web.UI.Page
    {
        static SqlConnection con;
        static SqlCommand cmd;
        
        string start, destination, seatType;
        static int amount=0,nop=0,tamt=0;
        

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txt_amount0_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btn_amt_Click(object sender, EventArgs e)
        {
            start = dd_from.SelectedItem.Text;
            destination = dd_to.SelectedItem.Text;
            seatType = dd_stype.SelectedItem.Text;
   
            if(seatType.Equals("Sleeper A/C"))
            {
                if(start.Equals("Chennai"))
                {
                    if(destination.Equals("Madurai"))
                        amount=3000;
                    else
                        amount=3500;
                }
                if(start.Equals("Trichy"))
                {
                    if(destination.Equals("Madurai"))
                        amount=2500;
                    else
                        amount=3000;
                }

            }
            else if(seatType.Equals("Sleeper Non A/C"))
            {
                if(start.Equals("Chennai"))
                {
                    if(destination.Equals("Madurai"))
                        amount=2000;
                    else
                        amount=2500;
                }
                if(start.Equals("Trichy"))
                {
                    if(destination.Equals("Madurai"))
                        amount=1500;
                    else
                        amount=2000;
                }
            }
            txt_amount.Text = amount.ToString();
            
        }

        protected void btn_camt_Click(object sender, EventArgs e)
        {
            try
            {
                string temp = txt_nop.Text;
                nop = Convert.ToInt32(temp);
                tamt = nop * amount;
                txt_tamt.Text = tamt.ToString();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        static SqlConnection GetConnection()
        {
            string conStr="Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
  
        }
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            con = GetConnection();
            start = dd_from.SelectedItem.Text;
            destination = dd_to.SelectedItem.Text;
            string x=txt_nop.Text;
            int nop = Convert.ToInt16(x);
            string x1 = txt_tamt.Text;
            int tamt = Convert.ToInt16(x1);

            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("res_passenger", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@Start", start));
            cmd.Parameters.Add(new SqlParameter("@Destination",destination));
            cmd.Parameters.Add(new SqlParameter("@NoofPassengers",nop));
            cmd.Parameters.Add(new SqlParameter("@TotalAmount",tamt));
           
            SqlParameter ridParam = cmd.Parameters.Add("@Rid", SqlDbType.Int);
            ridParam.Direction = ParameterDirection.Output;

            int res = cmd.ExecuteNonQuery();
            Response.Write("Reservation ID : "+(int)ridParam.Value);
            con.Close();
           
        }
    }
}