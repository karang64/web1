


create table tbl_BloodGroup1126179(BloodGroupID int identity(1,1) primary key,BloodGroupName varchar(20),DonorCount int)

create table tbl_Donor1126179(DonorID int Identity(1,1) primary key, DonorName varchar(50) not null, BloodGroupID int references tbl_BloodGroup1126179(BloodGroupID), DonorAddress varchar(50),DonorContact varchar(20),RegistrationDate varchar(20))

insert into tbl_BloodGroup1126179 values('A+',10)
insert into tbl_BloodGroup1126179 values('AB+',11)
insert into tbl_BloodGroup1126179 values('O+',12)
insert into tbl_BloodGroup1126179 values('O',13)

select * from tbl_BloodGroup1126179


******Procedure For Add Donor*******
alter procedure usp_AddDonor1126179(@dname varchar(20),@dbloodgrpid int,@daddress varchar(20),@dcontact varchar(20),@rdate varchar(20))
as
begin
insert into tbl_Donor1126179 values(@dname,@dbloodgrpid,@daddress,@dcontact,@rdate)
end

******Procedure For Update Donor*******
alter procedure usp_UpdateDonor1126179(@did int,@dname varchar(20),@daddress varchar(20),@dcontact varchar(20))
as
begin
update tbl_Donor1126179 set DonorName=@dname,DonorAddress=@daddress,DonorContact=@dcontact where DonorID=@did
end


******Procedure For View Donor*******
create procedure usp_ViewDonorByBloodGroup(@bloodgrpid int)
as
begin
select * from tbl_Donor1126179 where BloodGroupID=@bloodgrpid
end

******Procedure For View Donor Count*******
create procedure usp_ViewDonorCount1126179(@bloodgrpid int)
as
begin
select DonorCount from tbl_BloodGroup1126179 where BloodGroupID=@bloodgrpid
end
