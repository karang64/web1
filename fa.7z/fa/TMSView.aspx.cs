﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMS
{
    public partial class TMSView : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        static SqlConnection getConnection()
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
                return new SqlConnection(conStr);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            string userName = HttpContext.Current.User.Identity.Name;
            con = getConnection();
            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();
            com = new SqlCommand("procTMSViewBooking1092305", con);
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.Add(new SqlParameter("@username", userName));
            da = new SqlDataAdapter();
            da.SelectCommand = com;
            ds = new DataSet();
            da.Fill(ds);
            dgvData.DataSource = ds;
            dgvData.DataBind();
            con.Close();
        }
    }
}