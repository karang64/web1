﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMS
{
    public partial class TMSBook : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;

        static SqlConnection getConnection()
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
                return new SqlConnection(conStr);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {           
        }

        protected void ddlFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlTo.Items.Clear();
            ddlTo.Items.Add("CHENNAI");
            ddlTo.Items.Add("BANGLORE");
            ddlTo.Items.Add("KANYAKUMARI");
            ddlTo.Items.Add("HYDERABAD");
            ddlTo.Items.Add("MADURAI");
            ddlTo.Items.Remove(ddlTo.Items.FindByText(ddlFrom.Text));
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string userName = HttpContext.Current.User.Identity.Name;
            string fromLocation = ddlFrom.Text;
            string toLocation = ddlTo.Text;
            string DOJ = calDate.SelectedDate.ToShortDateString();
            string busType = (rbAC.Checked) ? rbAC.Text : rbNonAC.Text;
            int NOP = Convert.ToInt16(txtNOP.Text);
            con = getConnection();
            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();
            com = new SqlCommand("procTMSAddBooking1092305", con);
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.Add(new SqlParameter("@username", userName));
            com.Parameters.Add(new SqlParameter("@fromLocation", fromLocation));
            com.Parameters.Add(new SqlParameter("@toLocation", toLocation));
            com.Parameters.Add(new SqlParameter("@DOJ", DOJ));
            com.Parameters.Add(new SqlParameter("@NOP", NOP));
            com.Parameters.Add(new SqlParameter("@busType", busType));
            int i = com.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Booking Done with Booking ID !'+Math.floor((Math.random() * 10000) + 1));</script>");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('There is a problem in booking!');</script>");
            }
            con.Close();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            Response.Redirect("TMSBook.aspx");
        }
    }
}