﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using BloodMgmt_Types;
using System.Data;

namespace BloodMgmt_DAL
{
    public class Donor_DAL : IDonorDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter da = new SqlDataAdapter();


        public int AddDonor(IDonor objDonor)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("usp_AddDonor1126179", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@dname", objDonor.Donorname));
                cmd.Parameters.Add(new SqlParameter("@dbloodgrpid", objDonor.Bloodgroupid));
                cmd.Parameters.Add(new SqlParameter("@daddress", objDonor.Donoraddress));
                cmd.Parameters.Add(new SqlParameter("@dcontact", objDonor.Contactno));
                cmd.Parameters.Add(new SqlParameter("@rdate", objDonor.Registrationdate));

                int i = cmd.ExecuteNonQuery();
                con.Close();
                return i;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


        public DataSet ViewDonor(int bloodgrpid)
        {

            try
            {
                cmd = new SqlCommand("usp_ViewDonorByBloodGroup", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@bloodgrpid", bloodgrpid));
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;

            }
            catch (Exception ex)
            {

                return null;
            }

        }




        public int UpdateDoner(IDonor objDonor)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("usp_UpdateDonor1126179", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@did", objDonor.Donorid));
                cmd.Parameters.Add(new SqlParameter("@dname", objDonor.Donorname));
                cmd.Parameters.Add(new SqlParameter("@daddress", objDonor.Donoraddress));
                cmd.Parameters.Add(new SqlParameter("@dcontact", objDonor.Contactno));

                int i = cmd.ExecuteNonQuery();
                return i;
            }
            catch (Exception ex)
            {

                return 0;
            }


            
        }



        public int ViewDonorCount(int bloodgrpid)
        {
            int count=0;
            try
            {
               
                cmd = new SqlCommand("usp_ViewDonorCount1126179", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@bloodgrpid", bloodgrpid));
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                     count = int.Parse(dr[2].ToString());
                    return count;
                }
                return count;

            }
            catch (Exception ex)
            {

                return 0;
            }

        }

    }
}
