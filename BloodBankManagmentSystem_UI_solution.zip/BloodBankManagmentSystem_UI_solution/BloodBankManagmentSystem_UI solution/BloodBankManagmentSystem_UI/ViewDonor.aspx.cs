﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BloodBankManagment_BLL;
using BloodBankManagment_BO;
using BloodBankManagment_Types;

namespace BloodBankManagmentSystem_UI
{
    public partial class ViewDonor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Data_Bind();
            }
        }
        private void Data_Bind()
        {
            IBloodBLL bllobj = new BloodBLL();
            int a =int.Parse(Session["BloodGroupID"].ToString());
            IBloodBO obj = new BloodBO();
            obj.BloodGroupID = a;
            GridView1.DataSource = bllobj.ViewDonor(obj);
            GridView1.DataBind();

        }


        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            Data_Bind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[GridView1.EditIndex];
            IBloodBO objbo = new BloodBO();
            objbo.DonorID = Int32.Parse((row.FindControl("Label1") as Label).Text);
            objbo.DonorName= (row.FindControl("TextBox1") as TextBox).Text;
            objbo.DonorAddress = ((row.FindControl("TextBox2") as TextBox).Text);
            objbo.Contact = Int32.Parse((row.FindControl("TextBox4") as TextBox).Text);
            IBloodBLL objBLL = new BloodBLL();
            objBLL.UpdateDonor(objbo);
            Data_Bind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            Data_Bind();
        }
    }
}
