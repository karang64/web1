﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BloodMgmt_Types;
using BloodMgmt_BLL;
using BloodMgmt_BO;

namespace WebApplication3
{
    public partial class AddDonor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblBloodGroupName.Text = Session["BloodGroupName"].ToString();
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            string regdate = Calendar1.SelectedDate.Date.ToString("dd-MM-yyyy");
            txtdate.Text = regdate;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            IDonor objDonor=new Donor_BO();
            objDonor.Donorname = txtDonorName.Text;
            objDonor.Donoraddress = txtDonorAddress.Text;
            objDonor.Bloodgroupid = Convert.ToInt32(Session["BloodGroupID"].ToString());
            objDonor.Contactno = txtContactNo.Text;
            objDonor.Registrationdate = txtdate.Text;

            IDonorBLL objBLL = new Donor_BLL();
            int i = objBLL.Add_Donor(objDonor);



        }
    }
}