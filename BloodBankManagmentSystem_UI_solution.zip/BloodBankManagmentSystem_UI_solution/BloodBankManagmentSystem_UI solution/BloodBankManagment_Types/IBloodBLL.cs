﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BloodBankManagment_Types
{
  public interface IBloodBLL
    {
        void AddDonor(IBloodBO objbo);
        void UpdateDonor(IBloodBO objbo);
         DataSet ViewDonor(IBloodBO obj);
    }
}
