﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace BloodMgmt_Types
{
  public  interface IDonorDAL
    {
        int AddDonor(IDonor objDonor);
        DataSet ViewDonor(int bloodgrpid);
        int UpdateDoner(IDonor objDonor);
        int ViewDonorCount(int bloodgrpid);
    }
}
