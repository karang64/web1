﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string constr;
        SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        SqlCommandBuilder cb;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void filldataset()
        {
            string constr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
             conn = new SqlConnection(constr);

            com = new SqlCommand("validate2", conn);

            com.CommandType = CommandType.StoredProcedure;

            da = new SqlDataAdapter();
             da.SelectCommand = com;

            ds = new DataSet();

           
        
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataColumn[] keys = new DataColumn[1];
            keys[0] = dt.Columns["id"];
            dt.PrimaryKey = keys;

           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {



            filldataset();
            int f=0;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (((int)dr[0] == Convert.ToInt32(TextBox1.Text)) && ((string)dr[1] == TextBox2.Text))
                {

                    Response.Write("valid");
                    f=1;
                    break;

                }
            }

            if(f==0)
            {
                Response.Write("invalid");
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            filldataset();
         
          DataRow dr =  ds.Tables[0].NewRow();
        dr["id"] = Convert.ToInt32(TextBox1.Text);
        dr["password"]= TextBox2.Text;
        ds.Tables[0].Rows.Add(dr);
        cb = new SqlCommandBuilder(da);
        da.Update(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            filldataset();
            foreach (DataRow dr in ds.Tables[0].Rows)
            { 
                if((int)dr[0] == Convert.ToInt32(TextBox1.Text))
                { 
                dr["password"] =  TextBox2.Text;
                }
            }
        
      cb = new SqlCommandBuilder(da);
      da.Update(ds);
      GridView1.DataSource = ds.Tables[0];
      GridView1.DataBind();

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            filldataset();
      DataRow   drCurrent =ds.Tables[0].Rows.Find(TextBox1.Text);
   drCurrent.Delete();
   cb = new SqlCommandBuilder(da);
   da.Update(ds);
   GridView1.DataSource = ds.Tables[0];
   GridView1.DataBind();
          
        }
    }
}