﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace BloodMgmt_Types
{
  public  interface IDonorBLL
    {
        int Add_Donor(IDonor objDonor);
        DataSet View_Donor(int bloodgrpid);
        int Update_Donor(IDonor objDonor);
        int View_DonorCount(int bloodgrpid);
    }
}
