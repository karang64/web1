﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagment_Types
{
  public interface IBloodBO
    {
        int BloodGroupID { get; set; }
        string BloodGroupName { get; set; }
        string DonorAddress { get; set; }
        int DonorID { get; set; }
        string DonorName { get; set; }
        DateTime RegistrationDate { get; set; }
        int Contact { get; set; }
    }
}
